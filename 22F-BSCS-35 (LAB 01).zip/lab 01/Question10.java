 public class Question10{
	public static void main(String[] args){
		double a=2;
		double b=4;
		double c=8;
		double d=16;
			double exp=b*b-4*a*c;
			double sqt=Math.sqrt(exp);
			System.out.println("The ans is " + ( a*a + b*b + c*c/16));
			System.out.println("The ans is " + sqt);
			System.out.println("The ans is " + (a+b)*(c+d));	
	}
}