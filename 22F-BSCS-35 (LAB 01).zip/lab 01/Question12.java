public class Question2{
    public static void main(String[]args){
        string name =("SAFI AHMED");
        string rollno =("22F-BSCS-35");
        string date_of_birth =("23-April-2003");
        System.out.println("My name is: "+name);
        System.out.println("My rollno. is:"+rollno);
        System.out.println("My date of birth is:"+date_of_birth);
    }
}