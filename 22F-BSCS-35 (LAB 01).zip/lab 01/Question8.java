public class Question8{
	public static void main(String[] args){
		int a=150;
		int b=13;
			System.out.println("The Quotient is " + a/b);
			System.out.println("The reminder is " + a%b);
			
	}
}