public class Question6{
	public static void main(String[] args){
			int n1=15;
			int n2=30;
			int temp;
				temp=n1;
				n1=n2;
				n2=temp;
				System.out.println(n1);
				System.out.println(n2);
			
	}
}