public class Question5{
	public static void main(String[] args){
		
	int a1=3;
	int b1=5;
	int circumference1 =2*(a1+b1);
	int area1=a1*b1;
	System.out.println("When lenght=5 and width=3 of rectangle: ");
	System.out.println("Circumference= " + circumference1);
	System.out.println("Area= " + area1);
	
	double a=6.8;
	double b=2.6;
	double circumference =2*(a+b);
	double area=a*b;
	System.out.println("When lenght=6.8 and width=2.6 of rectangle: ");
	System.out.println("Circumference= " + circumference);
	System.out.println("Area= " + area);

	
	}
}