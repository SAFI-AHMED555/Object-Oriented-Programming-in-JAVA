 public class Question9{
	public static void main(String[] args){
		int sizeofint=Integer.SIZE;
		int sizeoffloat=Float.SIZE;
		int sizeofdouble=Double.SIZE;
		int sizeofchar=Character.SIZE;
		
			System.out.println("size of integer " + (sizeofint));
			System.out.println("size of float " + sizeoffloat);
			System.out.println("size of double " + sizeofdouble);
			System.out.println("size of character " + sizeofchar);
	}
 }